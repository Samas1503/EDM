
#include <iostream>
#include <stdlib.h>

using namespace std;

const int MAX=30;

typedef int tvector[MAX];

void menu(int &op);
void agregar(tvector &n,int &ocup,int nuevo);
void mostrar(tvector n,int ocup);
void mostrar2(tvector n,int inf, int sup);
void insertar(tvector &num,int &ocup,int nuevo);
bool busqueda_bin(tvector num, int ocup, int buscado);
bool busqueda_bin_recur(tvector num,int central , int bajo, int alto, int buscado, int ocup);
int busqueda_r_binaria(tvector num,int buscado, int bajo, int alto);
int suma_vec (tvector num,int fin);
void ver_vec (tvector num,int fin);
void insertar_dec(tvector &num,int &ocup,int nuevo);
void borrar(tvector &n,int &ocup,int borrado);
int buscar_secuencial(tvector num,int ocup,int buscado);
void insertar_primera(tvector &num,int &ocup,int nuevo);
void ver_vec_inv (tvector num,int ini, int fin);
void agregar_no_repetido(tvector &n,int &ocup,int nuevo);
void insertar_pos(tvector &num,int &ocup,int nuevo, int pos);
int enigma(tvector a, int ocup);
void borrar_duplicados(tvector &num,int &ocup,int borrado);
void borrar_local(tvector &num,int &ocup,int loc);
main()
{ tvector num; // declaracion del vector num
  int ocupado=-1; // declaracion e inicializacion de la variable ocupado
  int pos, i,cant,op, nuevo, central, buscado,bajo,alto,resul=-100,borrado,ini=0;

  do
  {
  system("cls");
  menu(op);
  switch (op)
  { case 1: 
           cout<<"ingrese un nro"<<endl;
	       cin>>nuevo;
		   agregar(num,ocupado,nuevo);  system("pause"); break;
	case 10: 
           cout<<"ingrese un nro"<<endl;
	       cin>>nuevo;
		   agregar_no_repetido(num,ocupado,nuevo);  system("pause"); break;
    case 2: cout<<"ingrese un nro"<<endl;
	       cin>>nuevo;
		   insertar(num,ocupado,nuevo);  system("pause"); break;
	case 20: cout<<"ingrese un nro"<<endl;
	       cin>>nuevo;
		   insertar_primera(num,ocupado,nuevo);  system("pause"); break;
	case 21: cout<<"ingrese un nro"<<endl;
	       cin>>nuevo;
	      cout<<"ingrese posici�n desde 0 hasta  "<<ocupado<<endl;
	       cin>>pos;
		   insertar_pos(num,ocupado,nuevo,pos);  system("pause"); break;	   	   
	case 22: cout<<"ingrese un nro"<<endl;
             cin>>nuevo;
             insertar_dec(num,ocupado,nuevo); break;
    case 3:cout<<"ingrese un nro a borrar"<<endl;
	       cin>>borrado;
           borrar(num,ocupado,borrado);  system("pause"); break;
    case 30:cout<<"ingrese un nro a borrar"<<endl;
	       cin>>borrado;
           borrar_duplicados(num,ocupado,borrado);  system("pause"); break;
    case 31:cout<<"ingrese una posicion a borrar"<<endl;
	       cin>>borrado;
	       borrar_local(num,ocupado,borrado);  system("pause"); break;
    case 4: cout<<"ingrese un nro a buscar"<<endl;
	       cin>>buscado;
		   if (busqueda_bin(num,ocupado, buscado)==true)
		        cout<<"el nro  "<<buscado<<" si se encuentra"<<endl; 
		   else
		     	cout<<"el nro  "<<buscado<<" NO se encuentra"<<endl; 
			break;
   	case 5: cout<<"ingrese un nro a buscar"<<endl;
            cin>>buscado;
	        bajo=0;
            alto=ocupado;
          	central=(bajo+alto)/2;
            resul=busqueda_r_binaria(num,buscado, bajo,alto);
		    if (resul>=0&&resul<=ocupado)
		      cout<<"el nro  "<<buscado<<" si se encuentra en la posici�n  "<<resul<<endl; 
		    else
		   	  cout<<"el nro  "<<buscado<<" NO se encuentra"<<endl; 
			break;	
    case 6:  mostrar(num,ocupado);   system("pause"); break;	   
	case 7: cout<<"Suma de los elementos del vector"<<suma_vec(num,ocupado)<<endl;  system("pause"); break;	
    case 70: cout<<"Enigma "<<enigma(num,ocupado)<<endl;  system("pause"); break;	
	case 8: ver_vec(num,ocupado);   system("pause");break;
	case 80: ver_vec_inv(num,ini,ocupado);   system("pause");break;
	case 9: cout<<"ingrese un nro a buscar"<<endl;
  	        cin>>buscado;
		    cout<<"el numero "<<buscado<<" se encontr� en la posici�n"<<buscar_secuencial(num,ocupado,buscado);
		    system("pause");
	case 0: cout<<"salir"<<endl;
	break;
    default: cout << "OPCION NO VALIDA" << endl;
  };
  }while(op!=0);
  cout << "\n Saliendo...." << endl;
  system("pause");
}

void agregar(tvector &n,int &ocup,int nuevo)
{	if (ocup==MAX-1)
	  cout << "Vector Completo";
	else
	  { ocup++;
	    n[ocup]=nuevo;
	  }
}
void agregar_no_repetido(tvector &n,int &ocup,int nuevo)
{	if (ocup==MAX-1)
	  cout << "Vector Completo";
	else
	  { 
	  if (buscar_secuencial(n,ocup,nuevo)==-1)
	  {
	  ocup++;
	  n[ocup]=nuevo;
	  }
	  else
	  {
	  	 cout << "Elemento repetido"<<endl;
	  }
	  }
}
void borrar(tvector &num,int &ocup,int borrado){
	int i=0;
	bool encontrado;
	encontrado=false;
	while (i<=ocup&&!encontrado)
	{
		if(borrado==num[i])
	        encontrado=true;
	    else
	        i++;
	}
	if(encontrado==true)
	{
        while(i<ocup)
		{
			num[i]=num[i+1];
            i++;
		}
        ocup--;
    }    
    else
	cout<<"EL ELEMENTO NO EXISTE"<<endl;
}
void borrar_duplicados(tvector &num,int &ocup,int borrado){
	tvector aux;
	int i=0, ocupos=-1;
	bool encontrado;
	encontrado=false;
	while (i<=ocup)
	{
		if(borrado==num[i])
			agregar(aux,ocupos,i);
		i++;
	}
	mostrar(aux,ocupos);
	mostrar(num,ocup);
	if (ocupos>-1)
	{
	for(int k=0;k<=ocupos;k++)
	{
		i=aux[k];
	    while(i<ocup)
		{
			num[i]=num[i+1];
            i++;
		}
        ocup--;
        mostrar(num,ocup);
    }    
    }
    else
	cout<<"EL ELEMENTO NO EXISTE"<<endl;
}
void borrar_local(tvector &num,int &ocup,int loc){
	int i=0;
	if (loc>=0 && loc<=ocup)
	{
		i=loc;
		while(i<ocup)
		{
			num[i]=num[i+1];
            i++;
		}
        ocup--;
	}
    else
	cout<<"EL ELEMENTO NO EXISTE"<<endl;
}
int buscar_secuencial(tvector num,int ocup,int buscado){
	int i=0;
	bool encontrado;
	encontrado=false;
	while (i<=ocup&&!encontrado)
	{
		if(buscado==num[i])
	        encontrado=true;
	    else
	        i++;
	}
	if(encontrado==true)
        return i;  
    else
     	return -1;
}
void menu(int &op)
{ cout << endl << "\n\t\n\tOPERACIONES BASICAS SOBRE VECTORES\n\t" << endl;
  cout << "\n\t1-Agregar" << endl;
  cout << "\n\t10-Agregar no repetido" << endl;
  cout << "\n\t2-Insertar" << endl;
  cout << "\n\t20-Insertar primera" << endl;
  cout << "\n\t21-Insertar posicion" << endl;
  cout << "\n\t22- Insertar decreciente "<<endl;
  cout << "\n\t3- Borrar"<<endl;
  cout << "\n\t30- Borrar duplicados"<<endl;
  cout << "\n\t31- Borrar posicion"<<endl;
  cout << "\n\t4-Busqueda binaria" << endl;
  cout << "\n\t5-Busqueda binaria recursiva" << endl;
  cout << "\n\t6-Mostrar" << endl;
  cout << "\n\t7-Sumar" << endl;
  cout << "\n\t70-Enigma" << endl;
  cout << "\n\t8-Ver" << endl;
  cout << "\n\t9-Buscar sec" << endl;
  cout << "\n\t0-Salir" << endl;
  cout << "\n\tSeleccione la operacion digitando el numero de la opcion[0 para salir]: ";
  cin >> op;
}
void mostrar(tvector n,int ocup)
{int i;
  for(i=0;i<=ocup;i++)
    cout << n[i] << " ";
  cout << endl;
}

bool busqueda_bin(tvector num, int ocup, int buscado)
{ int alto,bajo,central;
bool encontrado;
   
    bajo=0;
    alto=ocup;
    encontrado=false;
    while(encontrado == false && bajo<=alto)
    {
         central=(bajo+alto)/2;
         if(buscado==num[central])
		    encontrado=true;
		 else 
		 {
            if(buscado<num[central])
               alto=central-1;
            else
               bajo=central+1;
       	 }  
     }  
     return encontrado;
}

int busqueda_r_binaria(tvector num,int buscado, int bajo, int alto)
{
int central;
if (bajo>alto) return 0;
central = (bajo+alto) / 2;
if (num[central] < buscado) return busqueda_r_binaria(num,buscado,central+1,alto);
else if (num[central] > buscado) return busqueda_r_binaria(num,buscado,bajo,central-1);
else return central;
}

void insertar(tvector &num,int &ocup,int nuevo) 
{ int i,j; 
if (ocup==MAX-1) 
cout << "VECTOR COMPLETO" << endl;
 else 
 { 
 for(i=0;i<=ocup && nuevo>num[i];i++); 
 j=ocup;
  while (j>=i) 
  { 
  num[j+1]=num[j]; 
  j=j-1; 
  } 
  num[i]=nuevo; 
  ocup=ocup+1; 
  } 
  }
  
void insertar_dec(tvector &num,int &ocup,int nuevo) 
{ int i,j; 
if (ocup==MAX-1) 
cout << "VECTOR COMPLETO" << endl;
 else 
 { 
 for(i=0;i<=ocup && nuevo<num[i];i++); 
 j=ocup;
  while (j>=i) 
  { 
  num[j+1]=num[j]; 
  j=j-1; 
  } 
  num[i]=nuevo; 
  ocup=ocup+1; 
  } 
  }

void insertar_primera(tvector &num,int &ocup,int nuevo) 
{ int i; 
if (ocup==MAX-1) 
cout << "VECTOR COMPLETO" << endl;
 else 
 { 
 for(i=ocup;i>=0;i--)  
  num[i+1]=num[i]; 
 num[0]=nuevo; 
 ocup=ocup+1; 
 }
}

void insertar_pos(tvector &num,int &ocup,int nuevo, int pos) 
{ int i; 

if (ocup==MAX-1) 
cout << "VECTOR COMPLETO" << endl;
 else 
 if (ocup==-1) 
 {
 	cout << "VECTOR VACIO se inserta en posici�n 0" << endl;
 	num[0]=nuevo; 
    ocup=ocup+1; 
 }
 else
 { 
 if (pos>=0&&pos<=ocup)
 {
 	i=ocup;
 	while (i>=pos)
 	{
 		 num[i+1]=num[i];
         i--;
	 }
    num[pos]=nuevo;
    ocup=ocup+1;
  }
  else
  cout<<"posicion no valida"<<endl;
 }
}

int suma_vec (tvector num,int fin)
{   
	if(fin == 0)
		return num[fin];
	else
		return num[fin]+suma_vec (num,fin-1);
}
int enigma(tvector a, int ocup)
{int aux;
if (ocup==0)
	return a[ocup];
else
{ aux=enigma(a,ocup-1);
if (aux > a[ocup])
	return aux;
else
	return a[ocup];
}
}

void ver_vec (tvector num,int fin)
{   
	if(fin == 0)
		cout<<num[fin];
	else
	{
		ver_vec (num,fin-1);
		cout<<num[fin];
	}
}
void ver_vec_inv (tvector num,int ini, int fin)
{   
	if(fin == ini)
		cout<<num[ini];
	else
	{
		ver_vec_inv (num,ini+1,fin);
		cout<<num[ini];
	}
}
