#include <iostream>
#include <stdlib.h>

using namespace std;

const int MAX=30;

typedef int tvector[MAX]; 

void menu_ordenar(int &op);
void agregar(tvector &n,int &ocup,int nuevo);
void cambio(int &x, int &y);
void burbuja(tvector &n,int ocup);
void seleccion(tvector &n,int ocup);
void insercion(tvector &n,int ocup);
void shell(tvector &n,int ocup);
void rapido(tvector &n,int inf,int sup);
void mostrar(tvector n,int ocup);
void mostrar2(tvector n,int inf, int sup);

main()
{ tvector num; // declaraci?n del vector num
  int ocupado=-1; // declaraci?n e inicializaci?n de la variable ocupado
  int i,cant,op;
  cout << "Cuantos datos desea generar: ";
  cin >> cant;
  for(i=0;i<cant;i++)
    agregar(num,ocupado,rand()/1000); // se agregan al vector n?meros generados al azar (funci?n rand)
  cout << "\nLISTA ORIGINAL" << endl;
  mostrar(num,ocupado);
  menu_ordenar(op);
  switch (op)
  { case 1: burbuja(num,ocupado); break;
    case 2: seleccion(num,ocupado); break;
    case 3: insercion(num,ocupado); break;
    case 4: shell(num,ocupado); break;
    case 5: rapido(num,0,ocupado); break;
    default: cout << "OPCION NO VALIDA" << endl;
  };
  cout << "\nLISTA ORDENADA" << endl;
  mostrar(num,ocupado);
  system("pause");  	
}

void agregar(tvector &n,int &ocup,int nuevo)
{	if (ocup==MAX-1)
	  cout << "Vector Completo";
	else
	  { ocup++;
	    n[ocup]=nuevo;
	  }
}

void menu_ordenar(int &op)
{ cout << endl << "METODOS DE ORDENACION" << endl;
  cout << "1-Burbuja" << endl;
  cout << "2-Seleccion" << endl;
  cout << "3-Insercion" << endl;
  cout << "4-Shell" << endl;
  cout << "5-Rapido" << endl;
  cout << "\nSeleccione metodo de ordenacion [1,2,3,4,5]: ";
  cin >> op;
}

void cambio(int &x, int &y)
{ int aux;
  aux=x;
  x=y;
  y=aux;
}

//void burbuja(tvector &n,int ocup)
//{ int i,aux;
//  bool ordenado=false;
//  while (!ordenado)
//  { ordenado=true;
//    for(i=0;i<=ocup-1;i++)
//     {cout << endl << "Comparando " << n[i] << " y " << n[i+1] << endl;
//      mostrar(n,ocup);
//      if (n[i] > n[i+1])
//        { cambio(n[i],n[i+1]);
//          ordenado=false;
//        }
//     }   
//  }
//}
void burbuja(tvector &n,int ocup)
{ int i,aux;
  int contador=99;
  while (contador!=0)
  { contador=0;
    for(i=0;i<=ocup-1;i++)
     {cout << endl << "Comparando " << n[i] << " y " << n[i+1] << endl;
      mostrar(n,ocup);
      if (n[i] > n[i+1])
        { cambio(n[i],n[i+1]);
          contador++;
        }
     }   
  }
}

void seleccion(tvector &n,int ocup)
{ int i,j;
  for(i=0;i<ocup;i++)
   for(j=i+1;j<=ocup;j++)
    { cout << endl << "Comparando " << n[i] << " y " << n[j] << endl;   
      if (n[i] > n[j])
        cambio(n[i],n[j]);
      mostrar(n,ocup);
    }           
}

void insercion(tvector &n,int ocup)
{ int i,j,aux;
  for(i=1;i<=ocup;i++)
  { aux=n[i];
    cout << "Insertar: " << aux << endl;
    j=i-1;
    while(j>=0 && aux<n[j])
      { n[j+1]=n[j];
      	j--;
      }
    n[j+1]=aux;
    mostrar(n,ocup);      
  }	
}

void shell(tvector &n,int ocup)
{ int i,j,aux,salto;
  salto=ocup/2;
  while(salto!=0)
  { cout << "SALTO: " << salto << endl;
   for(i=salto;i<=ocup;i++)
   { aux=n[i];
     cout << "Valor a insertar: " << aux << endl;
     j=i-salto;
     while(j>=0 && aux<n[j])
       { n[j+salto]=n[j];
         j=j-salto;
       }
    n[j+salto]=aux;
    mostrar(n,ocup);  
   }
   salto=salto/2;
   mostrar(n,ocup);
  }  	
}

void rapido(tvector &n,int inf,int sup)
{ int i,j,pivote;
  i=inf;
  j=sup;
  pivote=n[(i+j)/2];
  mostrar2(n,inf,sup);
  while (i<=j)
  { while(n[i]<pivote)
      i++;
    while(n[j]>pivote)
      j--;  
  	if (i<=j)
	  {cambio(n[i],n[j]);
  	   i++;
  	   j--;
	  }
  }
  if (i<sup)
    {cout << "Por derecha: " << pivote << endl;
     rapido(n,i,sup);}
  if (j>inf)
    {cout << "Por izquierda: " << pivote << endl;
    rapido(n,inf,j);}
  
}

void mostrar(tvector n,int ocup)
{int i;
  for(i=0;i<=ocup;i++)
    cout << n[i] << " ";
  cout << endl;  
}

void mostrar2(tvector n,int inf, int sup)
{int i;
  for(i=inf;i<=sup;i++)
    cout << n[i] << " ";
  cout << endl;  
}
